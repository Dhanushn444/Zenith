﻿using SneakerDAL;

namespace SneakerLIB
{
    public class Orders
    {
        public int Id { get; set; }
        public int OrderDate { get; set; }
        public ICollection<OrderShoes> OrderShoes { get; set; }
    }
}
