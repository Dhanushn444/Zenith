﻿using SneakerDAL;

namespace SneakerLIB
{
    public class Shoes : Orders, ICart
    {


        private bool _shoeBuy = false;
        private bool _cartView = false;

        public void Buy()
        {
            _shoeBuy = true;
        }

        public void ViewCart()
        {
            _cartView = true;
        }
        public int shoeId { get; set; }
        public string Gender { get; set; }
        public double shoePrice { get; set; }
        public string shoeStyle { get; set; }
        public string shoeName { get; set; }
        public string shoeColor { get; set; }
        public int shoeSize { get; set; }
        public ICollection<OrderShoes> OrderShoes { get; set; }


        static SneakerDbContext dbContext = new SneakerDbContext();

        public static void Add(string pName,int pSize )
        {
           dbContext.Shoes.Add(new SneakerDAL.Shoes() { shoeName=pName,shoeSize=pSize});
            dbContext.SaveChanges();
        }
        public static void Update(string pName, string pUpdatedValue)
        {
            var tobeUpdated = dbContext.Shoes
                    .ToList()
                    .Where(p => p.shoeName == pName)
                    .FirstOrDefault();

            tobeUpdated.shoeName = pUpdatedValue;
            dbContext.SaveChanges();
        }
        public static void Delete(string pName)
        {
            var tobedeleted = dbContext.Shoes
                     .ToList()
                     .Where(p => p.shoeName == pName)
                     .FirstOrDefault();
            dbContext.Shoes.Remove(tobedeleted);
            dbContext.SaveChanges();
        }
        public static List<SneakerDAL.Shoes> Get()
        {
            return dbContext.Shoes.ToList() ;
        }


    }




    public enum Gender
    {
        Male,
        Female
    }

    public enum shoeStyle
    {
        Sandals,
        Sneakers,
        Boots,
        Heels,
        Flats,
        Sports,
        Elegants
    }

    public enum shoeColor
    {
        Black,
        White,
        Red,
        Green,
        Blue,
        Silver,
        Yellow,
        Gold,
        Pink
    }


}
