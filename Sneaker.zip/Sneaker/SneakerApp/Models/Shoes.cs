﻿using SneakerDAL;
using SneakerLIB;
using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography.X509Certificates;

namespace SneakerApp.Models
{
    public class Shoes
    {
        [Required]
        public int shoeId { get; set; }
        [MaxLength(100)]
        public string Gender { get; set; }
        [Range(100,30000)]
        public double shoePrice { get; set; }
        public string shoeStyle { get; set; }
        [MaxLength(100)]
        public string shoeName { get; set; }
        public string shoeColor { get; set; }
        [Range(1,10)]
        public int shoeSize { get; set; }
    }
    public class ShoeOperations
    {
        static List<Shoes> _shoes = new List<Shoes>();
        public static List<Shoes> GetAllShoes()
        {
            if (_shoes.Count == 0)
            {
                _shoes.Add(new Shoes() { shoeId = 001, Gender="male", shoePrice=10000.00, shoeStyle="Sneakers", shoeName="Adidas", shoeColor="White", shoeSize =9});
                _shoes.Add(new Shoes() { shoeId = 002, Gender = "male", shoePrice = 5000.00, shoeStyle = "Sports", shoeName = "Puma", shoeColor = "Black", shoeSize = 7 });
                _shoes.Add(new Shoes() { shoeId = 003, Gender = "male", shoePrice = 25000.00, shoeStyle = "Sneakers", shoeName = "Nike ", shoeColor = "Maroon", shoeSize = 9 });
                _shoes.Add(new Shoes() { shoeId = 004, Gender = "male", shoePrice = 2000.00, shoeStyle = "Casuals", shoeName = "Bata", shoeColor = "Black", shoeSize = 10});

            }
            return _shoes;
        }

        public static Shoes Search(int pShoeId)
        {
            return GetAllShoes().Where(p => p.shoeId == pShoeId).FirstOrDefault();
        }

        internal static void CreateNew(Shoes s)
        {
            _shoes.Add(s);
        }
    }
}
