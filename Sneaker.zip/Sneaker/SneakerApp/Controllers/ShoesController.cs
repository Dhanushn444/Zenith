﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SneakerApp.Models;
using SneakerDAL;
using Shoes = SneakerApp.Models.Shoes;

namespace SneakerApp.Controllers
{
    public class ShoesController : Controller
    {
        [HttpGet("/shoes")]
        public IActionResult GetAllShoes()
        {
            var shoe = ShoeOperations.GetAllShoes();
            var Sneak=Shoes.(shoe => new SneakerDAL.Shoes
            {
                shoesId = s.shoeId,
                Gender = s.Gender
            }).ToList();
            return View("AllShoes",Sneak);
        }

    }
}
