﻿

using SneakerDAL;

namespace SneakerLIB
{
    public class OrderShoes
    {
        public int Id { get; set; }
        public Shoes shoeId { get; set; }
        public Orders orderId { get; set; }
        public int Quantity { get; set; }

    }
}
